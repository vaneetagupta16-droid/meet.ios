# Iris Flower Prediction

Step 1: go to python.org and install python version > 3.11X 

Step 2: Install Vs code and check add icon to desktop and open with code action to windows explorer

step 3: Open Folder in vs code


Step 4:  pip install flask, scikit-learn, pandas, numpy

Step5: Create app.py and start writing code inside it

Step 6: riun it in terminla using python app.py command

Step 7: push code to github repo

Step 8: Deploy on Render


